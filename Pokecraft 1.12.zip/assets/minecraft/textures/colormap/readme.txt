I AM A SET OF INSTRUCTIONS

To turn off minty green stuff, just put the color maps into the folder labeled "SWITCH".

To turn minty green back on, Cut the color maps and Paste them into this folder that I'm in.