Choose the lang file in "M" if you use the Male Protagonist armor.
Choose the lang file in "F" if you use the Female Protagonist armor