If you are using the Fast version of the Movement Plates, delete the "MovementPlate.png" MCMETA file.

If you are using older versions of Pixelmon prior to 4.1.4, you will want to use the old leafstone.png in the Customizer.