There is only the English file here because that's all I know how to speak. I'm afraid that if I tried to do other languages, I would butcher them horribly.

Use the file in the "M" folder if you use the Hilbert costume.
Use the file in the "F" folder if you use the Hilda costume.
Use the file in the "P" folder if you use the Team Plasma costume.